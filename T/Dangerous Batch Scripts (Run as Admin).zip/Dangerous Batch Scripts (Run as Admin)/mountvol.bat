@echo off
echo Run as Administrator before continuing!
mountvol c: /d
